
from argparse import ArgumentParser
from azureml.core import Run


new_run=Run.get_context()
ws=new_run.experiment.workspace
AP=ArgumentParser()
AP.add_argument('--testoutput',type=str)
args=AP.parse_args()
import os 
import pandas as pd

path=os.path.join(args.testoutput,'x_test.csv')
x_test=pd.read_csv(path)
path=os.path.join(args.testoutput,'y_test.csv')
y_test=pd.read_csv(path)
path=os.path.join(args.testoutput,'y_pred.csv')
y_pred=pd.read_csv(path)

import joblib
path=os.path.join(args.testoutput,'rfcmodel.pkl')
model=joblib.load(path)
score = model.score(x_test, y_test)

# Evaluate the RFC model
from sklearn.metrics import confusion_matrix
cm = confusion_matrix(y_test, y_pred)

cm_dict = {"schema_type": "confusion_matrix",
           "schema_version": "v1",
           "data": {"class_labels": ["N", "Y"],
                    "matrix": cm.tolist()}
           }

new_run.log_confusion_matrix("ConfusionMatrix", cm_dict)
new_run.log("Score", score)


# Complete the run
new_run.complete()
