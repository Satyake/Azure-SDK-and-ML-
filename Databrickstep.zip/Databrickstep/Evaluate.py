#!/usr/bin/env python
# coding: utf-8

# In[3]:


get_ipython().run_cell_magic('writefile', 'evaluate.py', 'from azureml.core import Workspace, Run\nimport argparse\nnew_run=Run.get_context()\nws=new_run.experiment.workspace\n\nparser=argparse.ArgumentParser()\nparser.add_argument("--testdata",type=str)\nargs=parser.parse_args()\nimport os \nimport pandas as pd\n\npath=os.path.join(args.testdata,\'x_test.csv\')\nx_test=pd.read_csv(path)\npath=os.path.join(args.testdata,\'y_test.csv\')\ny_test=pd.read_csv(path)\npath=os.path.join(args.testdata,\'y_predict.csv\')\ny_predict=pd.read_csv(path)\n\nimport joblib\nobj_file=os.path.join(args.testdata,\'xgboost_rfc_trained.pkl\')\nrfc=joblib.load(obj_file)\nscore=rfc.score(y_predict)\n\nfrom sklearn.metrics import confusion_matrix\n\nconfusion_matrix=confusion_matrix(y_test,y_predict)\ncmtx=   {\n       "schema_type": "confusion_matrix",\n       "schema_version": "1.0.0",\n       "data": {\n           "class_labels": ["0", "1", "2", "3"],\n           "matrix": confusion_matrix.tolist()\n           \n       }\n   }\nnew_run.log_confusion_matrix("confusionmatrix",cmtx)\nnew_run.log("Score",score)\nnew_run.complete()')


# In[ ]:




